from tkinter import *
from tkinter import ttk
 
fenster = Tk() 
fenster.geometry('200x100')

labelTop = Label(fenster,
                    text = "Choose your favourite month")
labelTop.grid(column=0, row=0)

comboExample = ttk.Combobox(fenster, 
                            values=[
                                    "January", 
                                    "February",
                                    "March",
                                    "April"])

comboExample.grid(column=0, row=1)
comboExample.current(2)

print(comboExample.current(), comboExample.get())

fenster.mainloop()