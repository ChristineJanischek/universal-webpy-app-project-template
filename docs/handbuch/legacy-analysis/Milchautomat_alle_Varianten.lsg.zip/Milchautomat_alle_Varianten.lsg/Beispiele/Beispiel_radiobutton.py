from tkinter import *

fenster = Tk()

v = IntVar()

#Variablen für die Auswertung der Radiobuttons
auswahl = IntVar()
wert = IntVar()
sprache = StringVar()

# Hilfsfunktionen
def ermittle_auswahl():
 auswahl = wert.get()
 return auswahl
 
def switch_sprache(auswahl):    
    switcher={
        1:#Sprache 1
            "Python",
        2:#Sprache 2
            "Perl"
        }
    return switcher.get(auswahl, 0.0)

# Zusammenführung 
def ausgeben():
    auswahl = ermittle_auswahl()
    sprache = switch_sprache(auswahl)
    lb_sprache_ausgabe.config(text=sprache)


#GUI - Benutzeroberfläche
Label(fenster, 
        text="""Choose a 
programming language:""",
        justify = LEFT,
        padx = 20).pack()
## Mit Radiobuttons
Radiobutton(fenster, 
              text="Python",
              padx = 20, 
              variable=wert, 
              value=1).pack(anchor=W)
Radiobutton(fenster, 
              text="Perl",
              padx = 20, 
              variable=wert, 
              value=2).pack(anchor=W)

Label(fenster, text="Sprache:").pack(anchor=W)
lb_sprache_ausgabe = Label(fenster, fg="blue", bg="yellow", relief = SUNKEN,
                           width = 17)
lb_sprache_ausgabe.pack(anchor=W)

# Berechnungsschaltfläche
bt_ausgeben = Button(fenster, text="ausgeben",
                      command=ausgeben)
bt_ausgeben.pack(anchor=W)
bt_ausgeben.config(height = 2, width = 20)

    
fenster.mainloop()