from tkinter import *

class Call(object): # CamelCase name for class

    def __init__(self, name):
        self.name = name

        root = Tk()
        options = ["typ1", "typ2", "typ3"]

        self.var = StringVar()

        self.label = Label(root, text='Test')
        self.label.grid(row=4, column=3)

        OptionMenu(root, self.var, *options, command=self.change_label).grid(row=0, column=3)

        root.mainloop()

    def change_label(self, event):
        self.label['text'] = 'Test ' + self.var.get()


a = Call('')