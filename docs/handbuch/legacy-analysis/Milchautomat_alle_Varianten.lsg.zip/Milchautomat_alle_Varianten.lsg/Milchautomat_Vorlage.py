#import tkinter über Tools/Manage packages...here -> thonny cimage Datei installieren
from tkinter import *
from tkinter import ttk
from PIL import ImageTk, Image
import locale

#Hier beginnt das Hauptprogramm mit der Benutzeroberfläche
fenster = Tk()
fenster.title("Milchautomat")

#Setting it up: Laden von Grafiken der Benutzeroberfläche
launcher = ImageTk.PhotoImage(Image.open("ic_launcher.png"))
logo = ImageTk.PhotoImage(Image.open("logo_final.png"))

#Displaying it: Anzeigen und Platzierung von Grafiken
launcherlabel = Label(fenster, image=launcher).grid(row=0, column=0)
logolabel = Label(fenster, image=logo).grid(row=14, column=3, sticky=(E)) 

#Variablen für die Auswertung des Dropdown-Menüs & der Radiobuttons 
flaschengroesse = DoubleVar()
milchpreis = DoubleVar()
flaschenpreis = DoubleVar()
wert  = IntVar()
auswahl = DoubleVar()

#In Hilfsfunktion/-Methode wird der Milchtyp aus der Combobox gelesen
    #Und zurückgegeben
def ermittle_milchtyp():
    #HIER felt Quellcode!!!
    return 0

#In Hilfsfunktion/-Methode wird der Milchreis anhand des Milchtyps ermittelt (ELIF)
    #Und zurückgegeben
def ermittle_milchpreis(milchtyp):
    #HIER felt Quellcode!!!
    return 0

#In Hilfsfunktion/-Methode wird der Wert für den gewählten Radiobutton gelesen
    #Und als Auswahl zurückgegeben
def ermittle_auswahl():
    #HIER felt Quellcode!!!
    return 0

#In Hilfsfunktion/-Methode wird anhand der Auswahl die eigentliche Falschengröße ermittelt (SWITCHER)
    #Und zurückgegeben
def switch_flaschengroesse(auswahl):    
    #HIER felt Quellcode!!!
    return 0

#In Hilfsfunktion/-Methode wird anhand des Milchpreises und der Flaschengröße der Flaschenpreis (fp = mp * fg) berechnet
    #Und als Flaschenpreis zurückgegeben
def berechne_flaschenpreis(milchpreis, flaschengroesse):
    #HIER felt Quellcode!!!
    return 0

#In Hilfsfunktion/-Methode wird anhand des Flaschenpreises der Zahlungsbetrag berechnet
    #Dazu wird die Anzahl gelesen
    #der Zahlungsbetrag (anzahl * flaschenpreis) berechnet und formatiert
    #Und dann in das entsprechende Lable geschrieben
def berechne_zahlungsbetrag(flaschenpreis):
    #HIER felt Quellcode!!!
    return 0
 
#Ablaufplan für die Anwendung - Funktions-/Methodenaufrufe: Zusammenführung der Zwischenergebnisse - Prinzip: Teile und Herrsche
    #Milchtyp ermitteln
    #Milchpreis ermitteln
    #Auswahl für die Flaschengröße ermitteln
    #Flaschengröße ermitteln
    #Flaschenpreis berechnen
    #Zahlungsbetrag berechnen
def berechne():   
    #HIER felt Quellcode!!!
    return 0
    
def leeren():
    #Eingabewerte und Ausgabefeld leeren   
    tf_anzahl.delete(0,END)
    tf_betrag.delete(0,END)
    lb_zahlungsbetrag_ausgabe.config(text="")
    
def schliessen():
    #Stoppt den Main-Loop und schießt somit Fenster ordentlich
    fenster.destroy()


#### GUI/Benutzeroberfläche: Formular Gridlayout####
# Zeile 2
lb_anzahl = Label(fenster, text="Anzahl (der Flaschen):")
lb_anzahl.grid(row = 2, column = 1, sticky=(W))
tf_anzahl = Entry(fenster)
tf_anzahl.grid(row = 2, column = 2, sticky=(W))
# Zeile 4 - Dropdown Menü
lb_milchtyp = Label(fenster,text = "Milchtyp wählen:")
lb_milchtyp.grid(row=4, column=1, sticky=(W))
lb_milchtyp = Entry(fenster)
milchtyp = StringVar()
cb_milchtyp = ttk.Combobox(fenster, textvariable=milchtyp)
cb_milchtyp['values'] = (
                  'Vollmilch', 
                  'Lactosefreie Milch',
                  'Fettarme Milch',
                  'Soyamilch')

cb_milchtyp.grid(row=4, column=2, sticky=(W))
cb_milchtyp.current(0)

#Zeile 5
lb_menge = Label(fenster, 
        text="""Menge:""")
lb_menge.grid(row=6, column=1, sticky=(W))

rb_menge = Radiobutton(fenster, 
              text="Große Flasche (1.5 Liter)",
              padx = 20, 
              variable=wert, 
              value=1)
rb_menge.grid(row=6, column=2, sticky=(W))

rb_menge = Radiobutton(fenster, 
              text="Normale Flasche (1.0 Liter)",
              padx = 20, 
              variable=wert, 
              value=2)
rb_menge.grid(row=6, column=3, sticky=(W))

rb_menge = Radiobutton(fenster, 
              text="Mittlere Flasche (0.7 Liter)",
              padx = 20, 
              variable=wert, 
              value=3)
rb_menge.grid(row=8, column=2, sticky=(W))

rb_menge = Radiobutton(fenster, 
              text="Kleine Flasche (0.5 Liter)",
              padx = 20, 
              variable=wert, 
              value=4)
rb_menge.grid(row=8, column=3, sticky=(W))

# Zeile 6
lb_ergebnis = Label(fenster, text="Zahlungsbetrag:")
lb_ergebnis.grid(row = 10, column = 1, sticky=(W))
lb_zahlungsbetrag_ausgabe = Label(fenster, fg="blue", bg="yellow", relief = SUNKEN,
                           width = 17)
lb_zahlungsbetrag_ausgabe.grid(row = 10, column = 2, sticky=(W))

lb_blank0 = Label(fenster, text="")
lb_blank0.grid(row = 3, column = 1)
lb_blank1 = Label(fenster, text="")
lb_blank1.grid(row = 5, column = 1)
lb_blank2 = Label(fenster, text="")
lb_blank2.grid(row = 11, column = 1)
lb_blank3 = Label(fenster, text="")
lb_blank3.grid(row = 14, column = 1)

# Berechnungsschaltfläche
bt_berechne = Button(fenster, text="berechne",
                      command=berechne)
bt_berechne.grid(row = 12, column = 1, sticky=(W))
bt_berechne.config(height = 2, width = 20)


# Leeren der Felder
bt_leeren = Button(fenster, text="leeren",
                      command=leeren)
bt_leeren.grid(row = 12, column = 2, sticky=(W))
bt_leeren.config(height = 2, width = 20)

# Schliessen des Fensters
bt_schliessen = Button(fenster, text="schliessen",
                      command=schliessen)
bt_schliessen.grid(row = 13, column = 1, sticky=(W))
bt_schliessen.config(height = 2, width = 20)
