#import tkinter über Tools/Manage packages...here -> thonny cimage Datei installieren
from tkinter import *
from tkinter import ttk
from PIL import ImageTk, Image
import numpy as np
import locale

#Hier beginnt das Hauptprogramm mit der Benutzeroberfläche
fenster = Tk()
fenster.title("Milchautomat")

#Setting it up: Laden von Grafiken der Benutzeroberfläche
launcher = ImageTk.PhotoImage(Image.open("ic_launcher.png"))
logo = ImageTk.PhotoImage(Image.open("logo_final.png"))

#Displaying it: Anzeigen und Platzierung von Grafiken
launcherlabel = Label(fenster, image=launcher).grid(row=0, column=0)
logolabel = Label(fenster, image=logo).grid(row=14, column=3, sticky=(E)) 

#Variablen für die Auswertung des Dropdown-Menüs & der Radiobuttons 
flaschengroesse = DoubleVar()
milchpreis = DoubleVar()
flaschenpreis = DoubleVar()
wert  = IntVar()
auswahl = DoubleVar()
#Liste für das erweiterbare Dropdown-Menü cb_milchtyp
milchtypen = ['Vollmilch', 'Lactosefreie Milch','Fettarme Milch','Soyamilch']
preise =[1.30,1.45,1.10,1.55]
#Anfangsinitialisierung
milchprodukte = ["Vollmilch - 1.30 €",
                 "Lactosefreie Milch - 1.45 €",
                 "Fettarme Milch - 1.10 €",
                 "Soyamilch - 1.55 €"]

#In Hilfsfunktion/-Methode wird der Milchtyp aus der Combobox gelesen
    #Und zurückgegeben
def ermittle_milchtyp():
        milchtyp = cb_milchtyp.get()
        return milchtyp

#In Hilfsfunktion/-Methode wird der Milchreis anhand des Milchtyps ermittelt (ELIF)
    #Und zurückgegeben
    #erweiterte Variante
def ermittle_milchpreis(milchtyp, milchtypen, preise):
    for i in range(len(milchtypen)):
        if (milchtyp == milchtypen[i]):
            milchpreis = preise[i]
    return milchpreis

#Erweiterung: Milchprodukt und Preis ermitteln - Milchprodukte
def ermittle_milchprodukte(milchtypen, preise,milchprodukte):
    for i in range(len(milchtypen)):
        milchprodukte[i] = milchtypen[i] + str(" - ") + str(preise[i]) + str(" €")
    return milchprodukte

#In Hilfsfunktion/-Methode wird der Wert für den gewählten Radiobutton gelesen
    #Und als Auswahl zurückgegeben
def ermittle_auswahl():
 auswahl = wert.get()
 return auswahl

#In Hilfsfunktion/-Methode wird anhand der Auswahl die eigentliche Falschengröße ermittelt (SWITCHER)
    #Und zurückgegeben
def switch_flaschengroesse(auswahl):    
    switcher={
        1:#Große Flasche
            1.5,
        2:#Normale Flasche
            1,           
        3:#Mittlere Flasche
            0.7,                
        4:#Kleine Flasche
            0.5
        }
    return switcher.get(auswahl, 0.0)

#In Hilfsfunktion/-Methode wird anhand des Milchpreises und der Flaschengröße der Flaschenpreis (fp = mp * fg) berechnet
    #Und als Flaschenpreis zurückgegeben
def berechne_flaschenpreis(milchpreis, flaschengroesse):
    flaschenpreis = milchpreis * flaschengroesse
    return flaschenpreis

#In Hilfsfunktion/-Methode wird anhand des Flaschenpreises der Zahlungsbetrag berechnet
    #Dazu wird die Anzahl gelesen
    #der Zahlungsbetrag (anzahl * flaschenpreis) berechnet und formatiert
    #Und dann in das entsprechende Lable geschrieben
def berechne_zahlungsbetrag(flaschenpreis):
    anzahl = int(tf_anzahl.get())
    zahlungsbetrag = locale.format_string("%.2f",anzahl * flaschenpreis,1)+" €"
    lb_zahlungsbetrag_ausgabe.config(text=zahlungsbetrag)
 
#Ablaufplan für die Anwendung - Funktions-/Methodenaufrufe: Zusammenführung der Zwischenergebnisse - Prinzip: Teile und Herrsche
    #Milchtyp ermitteln
    #Milchpreis ermitteln
    #Auswahl für die Flaschengröße ermitteln
    #Flaschengröße ermitteln
    #Flaschenpreis berechnen
    #Zahlungsbetrag berechnen
def berechne():   
    milchtyp = ermittle_milchtyp()
    milchpreis = float(ermittle_milchpreis(milchtyp,milchtypen, preise))
    auswahl = ermittle_auswahl()
    flaschengroesse = switch_flaschengroesse(auswahl)
    flaschenpreis = berechne_flaschenpreis(milchpreis, flaschengroesse)
    berechne_zahlungsbetrag(flaschenpreis)
#Ablauf: Eingabefenster (mit Grafik) mit Eingabemöglichkeit für ein neues Listenelement.
    #Die Komponente (Dropdownmenü - cb_milchtyp) wird auf der Benutzeroberfläche aktualisiert (macht config())     
def addItem():
    #Hier beginnt das Hauptprogramm mit der Benutzeroberfläche
    add_item_fenster = Toplevel()
    add_item_fenster.title("Milchprodukt und Preis hinzufügen")

    #Setting it up: Laden von Grafiken der Benutzeroberfläche
    launcher2 = ImageTk.PhotoImage(Image.open("ic_launcher.png"))
    logo2 = ImageTk.PhotoImage(Image.open("logo_final.png"))

    #Displaying it: Anzeigen und Platzierung von Grafiken
    launcherlabel2 = Label(add_item_fenster, image=launcher).grid(row=0, column=0)
    logolabel2 = Label(add_item_fenster, image=logo).grid(row=4, column=3, sticky=(E))
    
    #Deklaration des Eingabefeldes (ist eine GUI-Komponente) - milchtyp
    label_milchtyp= Label(add_item_fenster, text = "Milchprodukt:").grid(row=2, column=1,sticky=(W))
    label_preis= Label(add_item_fenster, text = "Preis:").grid(row=3, column=1,sticky=(W))
    
    
    #Deklaration des Eingabefeldes (ist eine GUI-Komponente) - milchtyp
    input_field_milchtyp = Entry(add_item_fenster)
    input_field_milchtyp.grid(row = 2, column = 2, sticky=(W))
    
    #Deklaration des Eingabefeldes (ist eine GUI-Komponente) - preis
    input_field_preis = Entry(add_item_fenster)
    input_field_preis.grid(row = 3, column = 2, sticky=(W))

    
    #holt sich auf Klick den Eingabewert
    #fügt den Wert der Liste hinzu
    #aktualisiert die Liste im Dropdownmanü
    def add():
        neuerMilchtyp = input_field_milchtyp.get()
        neuerPreis = input_field_preis.get()
        
        #Fügt neue Daten in die Listen ein
        milchtypen.append(neuerMilchtyp)
        preise.append(neuerPreis)
        milchprodukte.append(neuerMilchtyp + str(" - ") + neuerPreis + str(" €"))
        #aktualisieren der Komponente
        cb_milchtyp.config(values = milchprodukte)
        
        #Schließt das Eingabefenster
        add_item_fenster.destroy()
    
    #Deklaration der Schaltfläche (ist eine GUI-Komponente)
    add_button = Button(add_item_fenster, text = 'hinzufügen', command=add)
    add_button.grid(row = 4, column = 2, sticky=(W))
    add_button.config(height = 2, width = 10)    

def leeren():
    #Eingabewerte und Ausgabefeld leeren   
    tf_anzahl.delete(0,END)
    tf_betrag.delete(0,END)
    lb_zahlungsbetrag_ausgabe.config(text="")
    
def schliessen():
    #Stoppt den Main-Loop und schießt somit Fenster ordentlich
    fenster.destroy()


#### GUI/Benutzeroberfläche: Formular Gridlayout####
# Zeile 2
lb_anzahl = Label(fenster, text="Anzahl (der Flaschen):")
lb_anzahl.grid(row = 2, column = 1, sticky=(W))
tf_anzahl = Entry(fenster)
tf_anzahl.grid(row = 2, column = 2, sticky=(W))
# Zeile 4 - Dropdown Menü
lb_milchtyp = Label(fenster,text = "Milchprodukt und Preis wählen:  ")
lb_milchtyp.grid(row=4, column=1, sticky=(W))
lb_milchtyp = Entry(fenster)

#Intitalisieren der Combobox mit den Werten aus der Liste
milchprodukte = ermittle_milchprodukte(milchtypen, preise,milchprodukte)
milchtyp = StringVar(value = milchprodukte[0])
cb_milchtyp = ttk.Combobox(fenster, value=milchprodukte, textvariable=milchtyp)
cb_milchtyp.config(values = milchprodukte)
cb_milchtyp.grid(row=4, column=2, sticky=(W))
cb_milchtyp.current(0)

#Zeile 5
lb_menge = Label(fenster, 
        text="""Menge:""")
lb_menge.grid(row=6, column=1, sticky=(W))

rb_menge = Radiobutton(fenster, 
              text="Große Flasche (1.5 Liter)",
              padx = 20, 
              variable=wert, 
              value=1)
rb_menge.grid(row=6, column=2, sticky=(W))

rb_menge = Radiobutton(fenster, 
              text="Normale Flasche (1.0 Liter)",
              padx = 20, 
              variable=wert, 
              value=2)
rb_menge.grid(row=6, column=3, sticky=(W))

rb_menge = Radiobutton(fenster, 
              text="Mittlere Flasche (0.7 Liter)",
              padx = 20, 
              variable=wert, 
              value=3)
rb_menge.grid(row=8, column=2, sticky=(W))

rb_menge = Radiobutton(fenster, 
              text="Kleine Flasche (0.5 Liter)",
              padx = 20, 
              variable=wert, 
              value=4)
rb_menge.grid(row=8, column=3, sticky=(W))

# Zeile 6
lb_ergebnis = Label(fenster, text="Zahlungsbetrag:")
lb_ergebnis.grid(row = 10, column = 1, sticky=(W))
lb_zahlungsbetrag_ausgabe = Label(fenster, fg="blue", bg="yellow", relief = SUNKEN,
                           width = 17)
lb_zahlungsbetrag_ausgabe.grid(row = 10, column = 2, sticky=(W))

lb_blank0 = Label(fenster, text="")
lb_blank0.grid(row = 3, column = 1)
lb_blank1 = Label(fenster, text="")
lb_blank1.grid(row = 5, column = 1)
lb_blank2 = Label(fenster, text="")
lb_blank2.grid(row = 11, column = 1)
lb_blank3 = Label(fenster, text="")
lb_blank3.grid(row = 14, column = 1)

# Berechnungsschaltfläche
bt_berechne = Button(fenster, text="berechne",
                      command=berechne)
bt_berechne.grid(row = 12, column = 1, sticky=(W))
bt_berechne.config(height = 2, width = 20)


# Leeren der Felder
bt_leeren = Button(fenster, text="leeren",
                      command=leeren)
bt_leeren.grid(row = 12, column = 2, sticky=(W))
bt_leeren.config(height = 2, width = 20)

# Schliessen des Fensters
bt_schliessen = Button(fenster, text="schliessen",
                      command=schliessen)
bt_schliessen.grid(row = 13, column = 1, sticky=(W))
bt_schliessen.config(height = 2, width = 20)

# addItem
bt_additem = Button(fenster, text="Extra Milchprodukt und \n Preis hinzufügen",
                      command=addItem)
bt_additem.grid(row = 13, column = 2, sticky=(W))
bt_additem.config(height = 2, width = 20)
